exports.ok = this == exports;
exports.x = 33;
exports.filename = __filename;
exports.b = require('./b.js');
